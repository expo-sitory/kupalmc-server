package dev.ixpu.leaguemechanics.rune.keystones.resolve;

import dev.ixpu.leaguemechanics.rune.BaseRune;
import dev.ixpu.leaguemechanics.rune.RunePath;
import dev.ixpu.leaguemechanics.rune.RuneSlot;
import dev.ixpu.leaguemechanics.player.PlayerStats;
import dev.ixpu.leaguemechanics.manager.DamageManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.configuration.ConfigurationSection;

import net.kyori.adventure.text.Component;

public class Guardian extends BaseRune {

    private int MAX_PLAYERS = 5;
    private double ABSORPTION_PERCENTAGE = 0.80;

    private int COOLDOWN_SECONDS = 60;

    private static final double DETECTION_RANGE = 10.0;
    private final static int PEACE_DURATION_TICKS = 200;
    private final static int GUARD_RAISE_DURATION_TICKS = 200;
    private final static int ABSORPTION_DURATION_TICKS = 1000;

    private final Map<UUID, List<UUID>> trackedPlayers = new HashMap<>();
    private final Map<UUID, Integer> windupCounter = new HashMap<>();
    private final Map<UUID, Long> lastShieldTime = new HashMap<>();
    private final Map<UUID, Long> lastCombatTime = new HashMap<>();

    public Guardian(ConfigurationSection config) {
        super("guardian", RunePath.RESOLVE, RuneSlot.KEYSTONE);
        ConfigurationSection section = config.getConfigurationSection("runes.keystones.resolve.guardian");
        if (section != null) {
            this.MAX_PLAYERS = section.getInt("max-players", this.MAX_PLAYERS);
            this.ABSORPTION_PERCENTAGE = section.getDouble("absorption-percentage", this.ABSORPTION_PERCENTAGE);
            this.COOLDOWN_SECONDS = section.getInt("cooldown", this.COOLDOWN_SECONDS);
        }
        this.setCooldownSeconds(COOLDOWN_SECONDS);
    }

    @Override
    public void onEnable(Player player) {
        UUID uuid = player.getUniqueId();
        trackedPlayers.put(uuid, new ArrayList<>());
        windupCounter.put(uuid, 0);
        lastShieldTime.put(uuid, 0L);
        lastCombatTime.put(uuid, 0L);
    }

    @Override
    public void onDisable(Player player) {
        UUID uuid = player.getUniqueId();
        clearPlayerCooldown(player);
        trackedPlayers.remove(uuid);
        windupCounter.remove(uuid);
        lastShieldTime.remove(uuid);
        lastCombatTime.remove(uuid);
    }

    public void onProjectileHit(Player shooter, Entity target) {
        if (!(target instanceof LivingEntity livingTarget)) {
            return;
        }
        double statsDamage = playerDamage(shooter, target);
        double newHealth = Math.max(0   , livingTarget.getHealth() - statsDamage);

        shooter.sendMessage(Component.text("§7[Debug] §f[§aGuardian§f] (Projectile) Stats Damage = §d" + Math.ceil(statsDamage * 100) / 100.0));
        shooter.sendMessage(Component.text("§7[Debug] §f[§aGuardian§f] (Projectile) Target New HP = §d" + Math.ceil(newHealth * 100) / 100.0));

        livingTarget.setHealth(newHealth);
    }

    public void onAttack(Player attacker, Entity target) {
        if (!(target instanceof LivingEntity livingTarget)) {
            return;
        }

        double statsDamage = playerDamage(attacker, target);
        double newHealth = Math.max(0   , livingTarget.getHealth() - statsDamage);

        attacker.sendMessage(Component.text("§7[Debug] §f[§aGuardian§f] (Melee) Stats Damage = §d" + Math.ceil(statsDamage * 100) / 100.0));
        attacker.sendMessage(Component.text("§7[Debug] §f[§aGuardian§f] (Melee) Target New HP = §d" + Math.ceil(newHealth * 100) / 100.0));

        livingTarget.setHealth(newHealth);
    }

    public void onPlayerDamage(Player victim, double damage) {
        activateGuardian(victim, damage);
    }

    private void activateGuardian(Player player, Double damage) {
        UUID uuid = player.getUniqueId();
        lastCombatTime.put(uuid, System.currentTimeMillis());

        if (windupCounter.getOrDefault(uuid, 0) > 0) {
            windupCounter.put(uuid, 0);
            trackedPlayers.put(uuid, new ArrayList<>());
        }
    }

    private double playerDamage(Player player, Entity target) {
        DamageManager damageManager = new DamageManager();
        return damageManager.totalBonusDamage(player, target, 0);
    }

    @Override
    public void tick(Player player) {
        UUID playerUUID = player.getUniqueId();
        List<UUID> nearbyPlayers = getNearbyPeacefulPlayers(player);

        int windupCount = windupCounter.getOrDefault(playerUUID, 0);

        if (windupCount > 0) {
            String runeDisplay = getRuneDisplay(RuneState.WINDUP, player, windupCount, nearbyPlayers.size());
            setPlayerDisplay(player, runeDisplay);

            windupCounter.put(playerUUID, windupCount - 1);
            if (windupCount == 1) {
                activateEffects(player);
            }
            return;
        }

        trackedPlayers.put(playerUUID, nearbyPlayers);

        long lastCombat = lastCombatTime.getOrDefault(playerUUID, 0L);
        long currentTime = System.currentTimeMillis();
        long peaceDurationMs = PEACE_DURATION_TICKS * 50L;
        boolean playerIsPeaceful = (currentTime - lastCombat) >= peaceDurationMs;

        if (!nearbyPlayers.isEmpty() && playerIsPeaceful && !isOnCooldown(player)) {
            startGuardRaise(player);
            return;
        }

        if (isOnCooldown(player)) {
            String runeDisplay = getRuneDisplay(RuneState.COOLDOWN, player, 0, 0);
            setPlayerDisplay(player, runeDisplay);
            return;
        }

        String runeDisplay = getRuneDisplay(RuneState.IDLE, player, 0, 0);
        setPlayerDisplay(player, runeDisplay);
    }

    private List<UUID> getNearbyPeacefulPlayers(Player player) {
        List<UUID> peaceful = new ArrayList<>();
        long currentTime = System.currentTimeMillis();

        for (Player nearby : player.getWorld().getPlayers()) {
            if (nearby.getUniqueId().equals(player.getUniqueId())) {
                continue;
            }

            if (nearby.getLocation().distance(player.getLocation()) > DETECTION_RANGE) {
                continue;
            }

            long lastCombat = lastCombatTime.getOrDefault(nearby.getUniqueId(), 0L);
            long peaceDurationMs = PEACE_DURATION_TICKS * 50L;

            if ((currentTime - lastCombat) >= peaceDurationMs) {
                peaceful.add(nearby.getUniqueId());
                if (peaceful.size() >= MAX_PLAYERS) {
                    break;
                }
            }
        }

        return peaceful;
    }

    private void startGuardRaise(Player player) {
        UUID playerUUID = player.getUniqueId();
        List<UUID> nearbyPlayers = getNearbyPeacefulPlayers(player);
        trackedPlayers.put(playerUUID, nearbyPlayers);
        windupCounter.put(playerUUID, GUARD_RAISE_DURATION_TICKS);
        lastShieldTime.put(playerUUID, System.currentTimeMillis());
        player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.2f);
    }

    private void activateEffects(Player player) {
        UUID playerUUID = player.getUniqueId();
        List<UUID> shields = trackedPlayers.getOrDefault(playerUUID, new ArrayList<>());

        applyShield(player);
        player.playSound(player.getLocation(), Sound.ITEM_TRIDENT_RETURN, 1.0f, 1.5f);

        int count = 0;
        for (UUID trackedUUID : shields) {
            if (count >= MAX_PLAYERS) break;

            Player trackedPlayer = player.getServer().getPlayer(trackedUUID);
            if (trackedPlayer != null && trackedPlayer.isOnline()) {
                applyShield(trackedPlayer);
                trackedPlayer.playSound(trackedPlayer.getLocation(), org.bukkit.Sound.ITEM_TRIDENT_RETURN, 1.0f, 0.5f);
                count++;
            }
        }
        resetCooldown(player);
    }

    private void applyShield(Player player) {

        int maxHealth = (int) Math.ceil(player.getMaxHealth());
        int absorbAmount = (int) Math.ceil(maxHealth * ABSORPTION_PERCENTAGE / 4.0);

        player.addPotionEffect(new PotionEffect(
                PotionEffectType.ABSORPTION,
                ABSORPTION_DURATION_TICKS,
                Math.min(absorbAmount, 255),
                false,
                false
        ));
    }

    private void setPlayerDisplay(Player player, String runeDisplay) {
        PlayerStats playerStats = new PlayerStats();
        String statsDisplay = playerStats.getActionBarSections(player);

        String actionBarMessage = runeDisplay + " " + statsDisplay;
        player.sendActionBar(Component.text(actionBarMessage));
    }

    enum RuneState {
        WINDUP, COOLDOWN, IDLE
    }

    private String getRuneDisplay(RuneState state, Player player, int remaining, int nearbyCount) {
        return switch (state) {
            case COOLDOWN -> "§7《❖》 " + getCooldownDisplay(player);
            case WINDUP -> {
                String message;
                if (remaining > GUARD_RAISE_DURATION_TICKS * 2 / 3) {
                    message = "§a《§2❖》 " + nearbyCount + "/" + MAX_PLAYERS;
                } else if (remaining > GUARD_RAISE_DURATION_TICKS / 3) {
                    message = "§a《❖§2》 " + nearbyCount + "/" + MAX_PLAYERS;
                } else {
                    message = "§a《❖》 " + nearbyCount + "/" + MAX_PLAYERS;
                }
                yield message;
            }
            case IDLE -> "§2《❖》";
        };
    }
}