package dev.ixpu.leaguemechanics.rune.keystones.domination;

import dev.ixpu.leaguemechanics.LeagueMechanics;
import dev.ixpu.leaguemechanics.rune.RunePath;
import dev.ixpu.leaguemechanics.rune.RuneSlot;
import dev.ixpu.leaguemechanics.rune.StacksHandler;
import dev.ixpu.leaguemechanics.manager.DamageManager;
import dev.ixpu.leaguemechanics.player.PlayerStats;
import dev.ixpu.leaguemechanics.util.DebugLogger;
import dev.ixpu.leaguemechanics.listener.PlayerEventListener;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.configuration.ConfigurationSection;

import net.kyori.adventure.text.Component;


public class DarkHarvest extends StacksHandler {

    private double BASE_ADAPTIVE_DAMAGE_PER_STACK = 0.2;
    private int LEVEL_COST_PER_STACK = 5;

    int COOLDOWN_DURATION_SECONDS = 60;

    private static final double HEALTH_THRESHOLD = 0.50;
    private static final int REAP_DELAY_TICKS = 75;

    private LeagueMechanics plugin;
    private PlayerEventListener listener;

    public DarkHarvest(ConfigurationSection config, PlayerEventListener listener) {
        super("dark-harvest", RunePath.DOMINATION, RuneSlot.KEYSTONE, 20);
        this.listener = listener;
        ConfigurationSection section = config.getConfigurationSection("runes.keystones.domination.dark-harvest");
        if (section != null) {
            this.BASE_ADAPTIVE_DAMAGE_PER_STACK = section.getDouble("adaptive-damage-per-stack", this.BASE_ADAPTIVE_DAMAGE_PER_STACK);
            this.LEVEL_COST_PER_STACK = section.getInt("level-cost-per-stack", this.LEVEL_COST_PER_STACK);
            this.COOLDOWN_DURATION_SECONDS = section.getInt("cooldown", COOLDOWN_DURATION_SECONDS);
        }
        this.setCooldownSeconds(COOLDOWN_DURATION_SECONDS);
    }

    @Override
    public void onEnable(Player player) {
        //
    }

    public void onProjectileHit(Player shooter, Entity target) {
        activateDarkHarvest(shooter, target);
    }

    public void onAttack(Player attacker, Entity target) {
        activateDarkHarvest(attacker, target);
    }

    private void activateDarkHarvest(Player player, Entity target) {
        if (!(target instanceof LivingEntity livingTarget)) {
            return;
        }
        if (livingTarget.getMaxHealth() < 20) {
            return;
        }

        double targetHealth = livingTarget.getHealth();
        double maxHealth = livingTarget.getMaxHealth();
        double healthPercent = targetHealth / maxHealth;
        double newHealth = Math.clamp(livingTarget.getHealth() - keystoneDamage(player, target), 0, livingTarget.getMaxHealth());

        if (healthPercent >= HEALTH_THRESHOLD) {
            return;
        }

        DebugLogger.debug(player, "§7[Debug] §f[§dAttacker Stats§f] §f[§cDark Harvest§f] Keystone Damage = §d" + Math.ceil(keystoneDamage(player, target) * 100) / 100.0);
        DebugLogger.debug(player, "§7[Debug] §f[§dTarget§f] Target New HP = §d" + Math.ceil(newHealth * 100) / 100.0);

        livingTarget.setHealth(newHealth);

        if (isOnCooldown(player) || player.getLevel() < LEVEL_COST_PER_STACK) {
            return;
        }

        scheduleAddStack(player);
        resetCooldown(player);
    }

    private double keystoneDamage(Player player, Entity target) {
        if (listener.isAnyHotbarOnCooldown(player)) {
            return 0.0;
        }
        DamageManager damageManager = new DamageManager();
        damageManager.enablePerStackScaling();
        damageManager.enableAdaptiveScaling();

        int currentStacks = getStacks(player);
        return damageManager.DamageCalculation(player, target, currentStacks, BASE_ADAPTIVE_DAMAGE_PER_STACK, 0);
    }

    private void scheduleAddStack(Player attacker) {
        if (plugin == null) {
            stackCost(attacker);
            return;
        }
        plugin.getServer().getScheduler().scheduleSyncDelayedTask(plugin, () -> stackCost(attacker), REAP_DELAY_TICKS);
    }

    private void stackCost(Player player) {
        if (getStacks(player) >= maxStacks) {
            return;
        }

        player.setLevel(player.getLevel() - LEVEL_COST_PER_STACK);
        addStack(player);
        player.playSound(player.getLocation(), Sound.ENTITY_WITHER_HURT, 1.0f, 1.0f);
    }

    @Override
    public void tick(Player player) {
        int currentStacks = getStacks(player);

        if (isOnCooldown(player)) {
            String runeDisplay = getRuneDisplay(player, RuneState.COOLDOWN, currentStacks);
            setPlayerDisplay(player, runeDisplay);
            return;
        }
        if (currentStacks > 0) {
            String runeDisplay = getRuneDisplay(player, RuneState.STACKING, currentStacks);
            setPlayerDisplay(player, runeDisplay);
            return;
        }
        String runeDisplay = getRuneDisplay(player, RuneState.IDLE, currentStacks);
        setPlayerDisplay(player, runeDisplay);
    }

    private void setPlayerDisplay(Player player, String runeDisplay) {
        PlayerStats playerStats = new PlayerStats();
        String statsDisplay = playerStats.getActionBarSections(player);

        String actionBarMessage = runeDisplay + " " + statsDisplay;
        player.sendActionBar(Component.text(actionBarMessage));
    }

    enum RuneState {
        COOLDOWN, STACKING, IDLE
    }

    private String getRuneDisplay(Player player, RuneState state, int currentStacks) {
        return switch (state) {
            case COOLDOWN -> "§7👻 " + currentStacks + "/" + maxStacks + " | " + getCooldownDisplay(player);
            case STACKING -> "§c👻 " + currentStacks + "/" + maxStacks;
            case IDLE -> "§4👻";
        };
    }
}