package dev.ixpu.leaguemechanics.rune.keystones.precision;

import dev.ixpu.leaguemechanics.rune.RunePath;
import dev.ixpu.leaguemechanics.rune.RuneSlot;
import dev.ixpu.leaguemechanics.rune.StacksHandler;
import dev.ixpu.leaguemechanics.player.PlayerStats;
import dev.ixpu.leaguemechanics.manager.DamageManager;
import dev.ixpu.leaguemechanics.util.DebugLogger;
import dev.ixpu.leaguemechanics.listener.PlayerEventListener;

import java.util.*;

import org.bukkit.entity.Player;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.configuration.ConfigurationSection;

import net.kyori.adventure.text.Component;


public class LethalTempo extends StacksHandler {

    private double ATTACK_SPEED = 0.6;
    private double BASE_ADAPTIVE_DAMAGE = 0.7;

    private PlayerEventListener listener;

    private static final int MAXIMUM_STACKS = 6;
    private static final int ACTIVE_DURATION_TICKS = 60;
    private static final int STACK_DURATION_TICKS = 300;

    int COOLDOWN_DURATION_SECONDS = 30;

    private final Map<UUID, RuneState> playerState = new HashMap<>();
    private final Map<UUID, Integer> activeState = new HashMap<>();
    private final Map<UUID, Double> activeASBonus = new HashMap<>();
    private final Map<UUID, Map<UUID, List<Long>>> stackTimestamps = new HashMap<>();

    public LethalTempo(org.bukkit.configuration.ConfigurationSection config) {
        super("lethal-tempo", RunePath.PRECISION, RuneSlot.KEYSTONE, 6, 120);
        this.listener = listener;
        enablePerTargetStacking();

        ConfigurationSection section = config.getConfigurationSection("runes.keystones.precision.lethal-tempo");

        if (section != null) {
            this.ATTACK_SPEED = section.getDouble("attack-speed", this.ATTACK_SPEED);
            this.BASE_ADAPTIVE_DAMAGE = section.getDouble("base-adaptive-damage", this.BASE_ADAPTIVE_DAMAGE);
            this.COOLDOWN_DURATION_SECONDS = section.getInt("cooldown", COOLDOWN_DURATION_SECONDS);
        }
        this.setCooldownSeconds(COOLDOWN_DURATION_SECONDS);
    }

    @Override
    public void onEnable(Player player) {
        UUID uuid = player.getUniqueId();
        playerState.put(uuid, RuneState.STACKING);
        activeState.put(uuid, 0);
        activeASBonus.put(uuid, 0.0);
    }

    @Override
    public void onDisable(Player player) {
        UUID uuid = player.getUniqueId();
        super.onDisable(player);
        playerState.remove(uuid);
        activeState.remove(uuid);
        activeASBonus.remove(uuid);
        stackTimestamps.remove(uuid);
        clearPlayerCooldown(player);
    }

    public void onAttack(Player attacker, Entity target) {
        activateLethalTempo(attacker, target);
    }

    public void activateLethalTempo(Player player, Entity target) {
        UUID targetUUID = target.getUniqueId();
        RuneState state = playerState.getOrDefault(player.getUniqueId(), RuneState.STACKING);

        if (!(target instanceof LivingEntity livingTarget)) {
            return;
        }
        if (livingTarget.getMaxHealth() < 20) {
            return;
        }

        switchTarget(player, targetUUID);

        if (state == RuneState.ACTIVE) {
            double newHealth = Math.clamp(livingTarget.getHealth() - keystoneDamage(player, target, getStacks(player, targetUUID)), 0, livingTarget.getMaxHealth());

            DebugLogger.debug(player, "§7[Debug] §f[§dAttacker§f] §f[§eLethal Tempo§f] Keystone Damage = §d" + Math.ceil(keystoneDamage(player, target, getStacks(player, targetUUID)) * 100) / 100.0);
            DebugLogger.debug(player, "§7[Debug] §f[§dTarget§f] Target New HP = §d" + Math.ceil(newHealth * 100) / 100.0);

            livingTarget.setHealth(newHealth);

            livingTarget.setHealth(newHealth);
            refreshActiveTimer(player);
            return;
        }

        if (state == RuneState.STACKING) {
            addStackForTarget(player, targetUUID);
        }
    }

    private double keystoneDamage(Player player, Entity target, int currentStacks) {
        if (listener.isAnyHotbarOnCooldown(player)) {
            return 0.0;
        }
        DamageManager damageManager = new DamageManager();
        damageManager.enableAdaptiveScaling();
        damageManager.enablePerStackScaling();
        return damageManager.DamageCalculation(player, target, currentStacks, BASE_ADAPTIVE_DAMAGE, 0);
    }

    private void addStackForTarget(Player player, UUID targetUUID) {
        addStack(player, targetUUID);
        recordStackTimestamp(player, targetUUID);

        int currentStacks = getActiveStacks(player, targetUUID);

        if (currentStacks == MAXIMUM_STACKS) {
            enterActiveState(player);
        }
    }

    private void recordStackTimestamp(Player player, UUID targetUUID) {
        UUID playerUUID = player.getUniqueId();
        Map<UUID, List<Long>> playerTimestamps = stackTimestamps.computeIfAbsent(playerUUID, k -> new HashMap<>());
        List<Long> targetTimestamps = playerTimestamps.computeIfAbsent(targetUUID, k -> new ArrayList<>());
        targetTimestamps.add(System.currentTimeMillis());
    }

    private int getActiveStacks(Player player, UUID targetUUID) {
        expireOldStacks(player, targetUUID);
        return getStacks(player, targetUUID);
    }

    private void expireOldStacks(Player player, UUID targetUUID) {
        UUID playerUUID = player.getUniqueId();
        Map<UUID, List<Long>> playerTimestamps = stackTimestamps.get(playerUUID);

        if (playerTimestamps == null) {
            return;
        }

        List<Long> targetTimestamps = playerTimestamps.get(targetUUID);
        if (targetTimestamps == null || targetTimestamps.isEmpty()) {
            return;
        }

        long currentTime = System.currentTimeMillis();
        long stackDurationMs = STACK_DURATION_TICKS * 50L;

        targetTimestamps.removeIf(timestamp -> (currentTime - timestamp) > stackDurationMs);
    }

    private void enterActiveState(Player player) {
        UUID playerUUID = player.getUniqueId();
        playerState.put(playerUUID, RuneState.ACTIVE);
        activeState.put(playerUUID, ACTIVE_DURATION_TICKS);
        activeASBonus.put(playerUUID, ATTACK_SPEED);
        player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.2f);
    }

    private void refreshActiveTimer(Player player) {
        UUID playerUUID = player.getUniqueId();
        activeState.put(playerUUID, ACTIVE_DURATION_TICKS);
    }

    private int trackActiveStacks(Player player) {
        UUID lastTargetUUID = lastTarget.getOrDefault(player.getUniqueId(), null);
        int currentStacks = 0;
        if (lastTargetUUID != null) {
            currentStacks = getActiveStacks(player, lastTargetUUID);
        }
        return currentStacks;
    }

    public double getActiveASBonus(Player player) {
        return activeASBonus.getOrDefault(player.getUniqueId(), 0.0);
    }

    @Override
    public void tick(Player player) {
        UUID playerUUID = player.getUniqueId();

        if (isOnCooldown(player)) {
            String runeDisplay = getRuneDisplay(RuneState.COOLDOWN, player, 0);
            setPlayerDisplay(player, runeDisplay);
            return;
        }

        RuneState state = playerState.getOrDefault(playerUUID, RuneState.STACKING);

        if (state == RuneState.STACKING) {
            int currentStacks = trackActiveStacks(player);
            String runeDisplay = getRuneDisplay(RuneState.STACKING, player, currentStacks);
            setPlayerDisplay(player, runeDisplay);

        } else if (state == RuneState.ACTIVE) {
            int activeTime = activeState.get(playerUUID);
            activeTime--;
            activeState.put(playerUUID, activeTime);

            String runeDisplay = getRuneDisplay(RuneState.ACTIVE, player, activeTime);
            setPlayerDisplay(player, runeDisplay);

            if (activeTime == 0) {
                resetCooldown(player);
                playerState.put(playerUUID, RuneState.STACKING);
                activeASBonus.put(playerUUID, 0.0);
                resetStacks(player);
                clearPlayerTimestamps(player);
                player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_BEACON_DEACTIVATE, 1.0f, 1.2f);
            }
        }
    }

    private void clearPlayerTimestamps(Player player) {
        stackTimestamps.remove(player.getUniqueId());
    }

    private void setPlayerDisplay(Player player, String runeDisplay) {
        PlayerStats playerStats = new PlayerStats();
        String statsDisplay = playerStats.getActionBarSections(player);

        String actionBarMessage = runeDisplay + " " + statsDisplay;
        player.sendActionBar(Component.text(actionBarMessage));
    }

    enum RuneState {
        COOLDOWN, STACKING, ACTIVE
    }

    private String getRuneDisplay(RuneState state, Player player, int value) {
        return switch (state) {
            case COOLDOWN -> "§7⚚ " + getCooldownDisplay(player);
            case ACTIVE -> {
                double remainingSeconds = value / 20.0;
                yield String.format("§e⚚ (%.1fs)", remainingSeconds);
            }
            case STACKING -> {
                if (value == 0) {
                    yield "§6⚚";
                } else {
                    yield "§6⚚ " + value + "/6";
                }
            }
        };
    }
}