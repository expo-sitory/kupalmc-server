package dev.ixpu.leaguemechanics.rune.keystones.domination;

import dev.ixpu.leaguemechanics.player.PlayerStats;
import dev.ixpu.leaguemechanics.util.DebugLogger;
import dev.ixpu.leaguemechanics.rune.CooldownHandler;
import dev.ixpu.leaguemechanics.rune.RunePath;
import dev.ixpu.leaguemechanics.rune.RuneSlot;
import dev.ixpu.leaguemechanics.manager.DamageManager;
import dev.ixpu.leaguemechanics.manager.BuffManager;
import dev.ixpu.leaguemechanics.listener.PlayerEventListener;

import java.util.*;

import org.bukkit.entity.Player;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.configuration.ConfigurationSection;

import net.kyori.adventure.text.Component;


public class HailOfBlades extends CooldownHandler {
    private double ATTACK_SPEED = 0.10;
    private double TRUE_DAMAGE_PERCENT = 2;

    private double AD_PERCENTAGE_MULTIPLIER = 12.0;
    private double AP_PERCENTAGE_MULTIPLIER = 8.0;

    int COOLDOWN_DURATION_SECONDS = 60;

    private static final int WINDUP_TICKS = 200;
    private static final int STACK_DURATION_TICKS = 60;
    private static final int INACTIVITY_TIMEOUT_TICKS = 60;
    private static final int INITIAL_STACKS = 2;

    private PlayerEventListener listener;

    private final Map<UUID, Boolean> windupActive = new HashMap<>();
    private final Map<UUID, Integer> windupTicks = new HashMap<>();
    private final Map<UUID, Integer> lastWindupStage = new HashMap<>();
    private final Map<UUID, Boolean> activeState = new HashMap<>();
    private final Map<UUID, Double> activeASBonus = new HashMap<>();
    private final Map<UUID, List<Integer>> stackDurationTicks = new HashMap<>();
    private final Map<UUID, Integer> lastAttackTick = new HashMap<>();
    private final Map<UUID, Integer> currentStacks = new HashMap<>();

    public HailOfBlades(ConfigurationSection config) {
        super("hail-of-blades", RunePath.DOMINATION, RuneSlot.KEYSTONE);
        this.listener = listener;
        ConfigurationSection section = config.getConfigurationSection("runes.keystones.domination.hail-of-blades");
        if (section != null) {
            this.ATTACK_SPEED = section.getDouble("base-attack-speed", this.ATTACK_SPEED);
            this.TRUE_DAMAGE_PERCENT = section.getDouble("base-true-damage", this.TRUE_DAMAGE_PERCENT);
            this.AD_PERCENTAGE_MULTIPLIER = section.getDouble("ad-percentage-multiplier", this.AD_PERCENTAGE_MULTIPLIER);
            this.AP_PERCENTAGE_MULTIPLIER = section.getDouble("ap-percentage-multiplier", this.AP_PERCENTAGE_MULTIPLIER);
            this.COOLDOWN_DURATION_SECONDS = section.getInt("cooldown", COOLDOWN_DURATION_SECONDS);
        }
        this.setCooldownSeconds(COOLDOWN_DURATION_SECONDS);
    }

    @Override
    public void onEnable(Player player) {
        UUID uuid = player.getUniqueId();
        windupActive.put(uuid, false);
        windupTicks.put(uuid, 0);
        lastWindupStage.put(uuid, 0);
        activeState.put(uuid, false);
        activeASBonus.put(uuid, 0.0);
        stackDurationTicks.put(uuid, new ArrayList<>());
        lastAttackTick.put(uuid, 0);
        currentStacks.put(uuid, 0);
    }

    @Override
    public void onDisable(Player player) {
        UUID uuid = player.getUniqueId();
        clearPlayerCooldown(player);
        windupActive.remove(uuid);
        windupTicks.remove(uuid);
        lastWindupStage.remove(uuid);
        activeState.remove(uuid);
        activeASBonus.remove(uuid);
        stackDurationTicks.remove(uuid);
        lastAttackTick.remove(uuid);
        currentStacks.remove(uuid);
    }

    public void onCombat(Player player) {
        if (isOnCooldown(player)) {
            return;
        }
        activateHailofBlades(player, null);
    }

    public void onProjectileHit(Player shooter, Entity target) {
        activateHailofBlades(shooter, target);
    }

    public void onAttack(Player attacker, Entity target) {
        activateHailofBlades(attacker, target);
    }

    private void activateHailofBlades(Player player, Entity target) {
        UUID playerUUID = player.getUniqueId();

        if (!(target instanceof LivingEntity livingTarget)) {
            return;
        }
        if (livingTarget.getMaxHealth() < 20) {
            return;
        }

        double newHealth = Math.clamp(livingTarget.getHealth() - (keystoneDamage(player, target) * getScaledTrueDamage(player)), 0, livingTarget.getMaxHealth());

        if (windupActive.getOrDefault(playerUUID, false) || isOnCooldown(player)) {
            return;
        }
        if (activeState.getOrDefault(playerUUID, false)) {
            lastAttackTick.put(playerUUID, 0);
            currentStacks.put(playerUUID, currentStacks.getOrDefault(playerUUID, 0) - 1);

            DebugLogger.debug(player, "§7[Debug] §f[§dAttacker§f] §f[§cHail of Blades§f] Keystone Damage = §d" + Math.ceil(keystoneDamage(player, target) * 100) / 100.0);
            DebugLogger.debug(player, "§7[Debug] §f[§dTarget§f] Target New HP = §d" + Math.ceil(newHealth * 100) / 100.0);

            livingTarget.setHealth(newHealth);

            return;
        }
        windupActive.put(playerUUID, true);
        windupTicks.put(playerUUID, WINDUP_TICKS);
        lastWindupStage.put(playerUUID, 0);
    }

    private double keystoneDamage(Player player, Entity target) {
        if (listener.isAnyHotbarOnCooldown(player)) {
            return 0.0;
        }
        DamageManager damageManager = new DamageManager();
        damageManager.enableTrueDamage();
        return damageManager.DamageCalculation(player, target, 0, 0, TRUE_DAMAGE_PERCENT);
    }

    private int trackActiveStacks(Player player) {
        UUID playerUUID = player.getUniqueId();

        int inactivityCount = lastAttackTick.getOrDefault(playerUUID, 0);
        inactivityCount++;
        lastAttackTick.put(playerUUID, inactivityCount);

        if (inactivityCount >= INACTIVITY_TIMEOUT_TICKS) {
            currentStacks.put(playerUUID, currentStacks.getOrDefault(playerUUID, 0) - 1);
            player.playSound(player.getLocation(), org.bukkit.Sound.ITEM_TRIDENT_HIT_GROUND, 1.0f, 0.5f);
            lastAttackTick.put(playerUUID, 0);
        }

        return currentStacks.getOrDefault(playerUUID, 0);
    }

    private double getScaledTrueDamage(Player player) {
        BuffManager buffManager = new BuffManager();
        return buffManager.calculateBuffValue(
                player,
                TRUE_DAMAGE_PERCENT,
                AD_PERCENTAGE_MULTIPLIER,
                AP_PERCENTAGE_MULTIPLIER
        );
    }

    private void deactivateEffect(Player player) {
        UUID playerUUID = player.getUniqueId();
        activeState.put(playerUUID, false);
        activeASBonus.put(playerUUID, 0.0);
        currentStacks.put(playerUUID, 0);
        windupTicks.put(playerUUID, 0);
        windupActive.put(playerUUID, false);
        lastWindupStage.put(playerUUID, 0);
        lastAttackTick.put(playerUUID, 0);
        stackDurationTicks.put(playerUUID, new ArrayList<>());

        resetCooldown(player);
    }

    public double getActiveASBonus(Player player) {
        return activeASBonus.getOrDefault(player.getUniqueId(), 0.0);
    }

    @Override
    public void tick(Player player) {
        UUID playerUUID = player.getUniqueId();

        if (isOnCooldown(player)) {
            String runeDisplay = getRuneDisplay(player, RuneState.COOLDOWN, 0);
            setPlayerDisplay(player, runeDisplay);
            return;
        }

        if (windupActive.getOrDefault(playerUUID, false)) {
            int windupCount = windupTicks.getOrDefault(playerUUID, 0);
            windupCount--;
            windupTicks.put(playerUUID, windupCount);

            String runeDisplay = getRuneDisplay(player, RuneState.WINDUP, windupCount);
            setPlayerDisplay(player, runeDisplay);

            if (windupCount <= 0) {
                windupActive.put(playerUUID, false);
                activateEffect(player);
            }
            return;
        }

        if (activeState.getOrDefault(playerUUID, false)) {
            int stacks = trackActiveStacks(player);

            if (stacks <= 0) {
                deactivateEffect(player);
                return;
            }

            String runeDisplay = getRuneDisplay(player, RuneState.ACTIVE, stacks);
            setPlayerDisplay(player, runeDisplay);
            return;
        }

        String runeDisplay = getRuneDisplay(player, RuneState.IDLE, 0);
        setPlayerDisplay(player, runeDisplay);
    }

    private void activateEffect(Player player) {
        UUID playerUUID = player.getUniqueId();
        activeState.put(playerUUID, true);
        activeASBonus.put(playerUUID, ATTACK_SPEED);
        lastAttackTick.put(playerUUID, 0);
        currentStacks.put(playerUUID, INITIAL_STACKS);

        List<Integer> durations = new ArrayList<>();
        for (int i = 0; i < INITIAL_STACKS; i++) {
            durations.add(STACK_DURATION_TICKS);
        }
        stackDurationTicks.put(playerUUID, durations);

        player.playSound(player.getLocation(), org.bukkit.Sound.ITEM_TRIDENT_THROW, 1.0f, 2.0f);
    }

    private void setPlayerDisplay(Player player, String runeDisplay) {
        PlayerStats playerStats = new PlayerStats();

        String statsDisplay = playerStats.getActionBarSections(player);

        String actionBarMessage = runeDisplay + " " + statsDisplay;
        player.sendActionBar(Component.text(actionBarMessage));
    }

    enum RuneState {
        COOLDOWN, WINDUP, ACTIVE, IDLE
    }

    private String getRuneDisplay(Player player, RuneState state, int value) {
        return switch (state) {
            case COOLDOWN -> "§7❛❟❛ " + getCooldownDisplay(player);
            case ACTIVE -> "§c❛❟❛ " + value + "/" + INITIAL_STACKS;
            case WINDUP -> getWindupDisplay(player, value);
            case IDLE -> "§4❛❟❛";
        };
    }

    private String getWindupDisplay(Player player, int remainingTicks) {
        UUID playerUUID = player.getUniqueId();

        int currentStage;
        String message;

        if (remainingTicks > (WINDUP_TICKS * 2 / 3)) {
            currentStage = 1;
            message = "§c❛§4❟❛";
        } else if (remainingTicks > (WINDUP_TICKS / 3)) {
            currentStage = 2;
            message = "§c❛❟§4❛";
        } else {
            currentStage = 3;
            message = "§c❛❟❛";
        }

        int lastStage = lastWindupStage.getOrDefault(playerUUID, 0);
        if (currentStage != lastStage) {
            player.playSound(player.getLocation(), org.bukkit.Sound.ITEM_TRIDENT_HIT, 1.0f, 2.0f);
            lastWindupStage.put(playerUUID, currentStage);
        }

        return message;
    }
}