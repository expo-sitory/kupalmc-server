package dev.ixpu.leaguemechanics.rune.keystones.domination;

import dev.ixpu.leaguemechanics.player.PlayerStats;
import dev.ixpu.leaguemechanics.rune.BaseRune;
import dev.ixpu.leaguemechanics.rune.RunePath;
import dev.ixpu.leaguemechanics.rune.RuneSlot;
import dev.ixpu.leaguemechanics.manager.DamageManager;
import dev.ixpu.leaguemechanics.manager.BuffManager;

import java.util.*;

import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;

import org.bukkit.entity.Player;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.configuration.ConfigurationSection;

import net.kyori.adventure.text.Component;


public class HailOfBlades extends BaseRune {
    private double BASE_ATTACK_SPEED = 0.10;
    private double BASE_TRUE_DAMAGE = 1.25;

    private double AD_PERCENTAGE_MULTIPLIER = 0.8;
    private double AP_PERCENTAGE_MULTIPLIER = 0.6;

    int COOLDOWN_DURATION_SECONDS = 60;

    private static final int WINDUP_TICKS = 200;
    private static final int STACK_DURATION_TICKS = 60;
    private static final int INACTIVITY_TIMEOUT_TICKS = 60;
    private static final int INITIAL_STACKS = 2;

    private final Map<UUID, Boolean> windupActive = new HashMap<>();
    private final Map<UUID, Integer> windupTicks = new HashMap<>();
    private final Map<UUID, Integer> lastWindupStage = new HashMap<>();
    private final Map<UUID, Boolean> activeState = new HashMap<>();
    private final Map<UUID, List<Integer>> stackDurationTicks = new HashMap<>();
    private final Map<UUID, Integer> lastAttackTick = new HashMap<>();
    private final Map<UUID, Integer> currentStacks = new HashMap<>();
    private final Map<UUID, List<AttributeModifier>> activeModifiers = new HashMap<>();

    public HailOfBlades(ConfigurationSection config) {
        super("hail-of-blades", RunePath.DOMINATION, RuneSlot.KEYSTONE);
        ConfigurationSection section = config.getConfigurationSection("runes.keystones.domination.hail-of-blades");
        if (section != null) {
            this.BASE_ATTACK_SPEED = section.getDouble("base-attack-speed", this.BASE_ATTACK_SPEED);
            this.BASE_TRUE_DAMAGE = section.getDouble("base-true-damage", this.BASE_TRUE_DAMAGE);
            this.AD_PERCENTAGE_MULTIPLIER = section.getDouble("ad-percentage-multiplier", this.AD_PERCENTAGE_MULTIPLIER);
            this.AP_PERCENTAGE_MULTIPLIER = section.getDouble("ap-percentage-multiplier", this.AP_PERCENTAGE_MULTIPLIER);
            this.COOLDOWN_DURATION_SECONDS = section.getInt("cooldown", COOLDOWN_DURATION_SECONDS);
        }
        this.setCooldownSeconds(COOLDOWN_DURATION_SECONDS);
    }

    @Override
    public void onEnable(Player player) {
        UUID uuid = player.getUniqueId();
        windupActive.put(uuid, false);
        windupTicks.put(uuid, 0);
        lastWindupStage.put(uuid, 0);
        activeState.put(uuid, false);
        stackDurationTicks.put(uuid, new ArrayList<>());
        lastAttackTick.put(uuid, 0);
        currentStacks.put(uuid, 0);
        activeModifiers.put(uuid, new ArrayList<>());
    }

    @Override
    public void onDisable(Player player) {
        UUID uuid = player.getUniqueId();
        removeAllModifiers(player);
        clearPlayerCooldown(player);
        windupActive.remove(uuid);
        windupTicks.remove(uuid);
        lastWindupStage.remove(uuid);
        activeState.remove(uuid);
        stackDurationTicks.remove(uuid);
        lastAttackTick.remove(uuid);
        currentStacks.remove(uuid);
        activeModifiers.remove(uuid);
    }

    public void onProjectileHit(Player shooter, Entity target) {
        if (!(target instanceof LivingEntity livingTarget)) {
            return;
        }
        double newHealth = Math.max(0, livingTarget.getHealth() - playerDamage(shooter, target));
        livingTarget.setHealth(newHealth);
    }

    public void onAttack(Player attacker, Entity target) {
        if (!(target instanceof LivingEntity livingTarget)) {
            return;
        }
        double newHealth = Math.max(0, livingTarget.getHealth() - playerDamage(attacker, target));
        livingTarget.setHealth(newHealth);

        activateHailofBlades(attacker, target);
    }

    private void activateHailofBlades(Player player, Entity target) {
        UUID playerUUID = player.getUniqueId();

        if (!(target instanceof LivingEntity livingTarget)) {
            return;
        }
        if (livingTarget.getMaxHealth() < 20) {
            return;
        }

        double newHealth = Math.max(0, (livingTarget.getHealth() - keystoneDamage(player, target)) * getScaledTrueDamage(player));

        if (windupActive.getOrDefault(playerUUID, false) || isOnCooldown(player)) {
            return;
        }
        if (activeState.getOrDefault(playerUUID, false)) {
            lastAttackTick.put(playerUUID, 0);

            livingTarget.setHealth(newHealth);

            List<Integer> durations = stackDurationTicks.getOrDefault(playerUUID, new ArrayList<>());
            for (int i = 0; i < durations.size(); i++) {
                durations.set(i, STACK_DURATION_TICKS);
            }
            return;
        }
        windupActive.put(playerUUID, true);
        windupTicks.put(playerUUID, WINDUP_TICKS);
        lastWindupStage.put(playerUUID, 0);
    }
    
    private double keystoneDamage(Player player, Entity target) {
        DamageManager damageManager = new DamageManager();
        return damageManager.totalBonusDamage(player, target, 0);
    }

    private double playerDamage(Player player, Entity target) {
        DamageManager damageManager = new DamageManager();
        return damageManager.totalBonusDamage(player, target, 0);
    }


    private int trackActiveStacks(Player player) {
        UUID playerUUID = player.getUniqueId();
        List<Integer> durations = stackDurationTicks.getOrDefault(playerUUID, new ArrayList<>());

        int inactivityCount = lastAttackTick.getOrDefault(playerUUID, 0);
        inactivityCount++;
        lastAttackTick.put(playerUUID, inactivityCount);

        if (inactivityCount >= INACTIVITY_TIMEOUT_TICKS && !durations.isEmpty()) {
            durations.removeFirst();
            currentStacks.put(playerUUID, currentStacks.getOrDefault(playerUUID, 0) - 1);

            for (int i = 0; i < durations.size(); i++) {
                durations.set(i, STACK_DURATION_TICKS);
            }

            player.playSound(player.getLocation(), org.bukkit.Sound.ITEM_TRIDENT_HIT_GROUND, 1.0f, 0.5f);
            lastAttackTick.put(playerUUID, 0);
        }

        List<Integer> expiredIndices = new ArrayList<>();
        for (int i = 0; i < durations.size(); i++) {
            int duration = durations.get(i);
            duration--;
            durations.set(i, duration);

            if (duration <= 0) {
                expiredIndices.add(i);
            }
        }

        for (int i = expiredIndices.size() - 1; i >= 0; i--) {
            durations.remove((int) expiredIndices.get(i));
            currentStacks.put(playerUUID, currentStacks.getOrDefault(playerUUID, 0) - 1);
            player.playSound(player.getLocation(), org.bukkit.Sound.ITEM_TRIDENT_HIT_GROUND, 1.0f, 0.5f);
        }

        return currentStacks.getOrDefault(playerUUID, 0);
    }

    private double getScaledTrueDamage(Player player) {
        BuffManager buffManager = new BuffManager();
        return buffManager.calculateBuffValue(
                player,
                BASE_TRUE_DAMAGE,
                AD_PERCENTAGE_MULTIPLIER,
                AP_PERCENTAGE_MULTIPLIER
        );
    }

    private double getScaledAttackSpeed(Player player) {
        BuffManager buffManager = new BuffManager();
        return buffManager.calculateBuffValue(
                player,
                BASE_ATTACK_SPEED,
                AD_PERCENTAGE_MULTIPLIER,
                AP_PERCENTAGE_MULTIPLIER
        );
    }

    private void deactivateEffect(Player player) {
        UUID playerUUID = player.getUniqueId();
        activeState.put(playerUUID, false);
        currentStacks.put(playerUUID, 0);
        windupTicks.put(playerUUID, 0);
        windupActive.put(playerUUID, false);
        lastWindupStage.put(playerUUID, 0);
        lastAttackTick.put(playerUUID, 0);
        stackDurationTicks.put(playerUUID, new ArrayList<>());

        resetCooldown(player);
        removeAllModifiers(player);
    }

    @SuppressWarnings("removal")
    private void applyAttackSpeedBonus(Player player) {
        removeAllModifiers(player);
        UUID modifierUUID = UUID.nameUUIDFromBytes(("hail-of-blades-" + player.getUniqueId()).getBytes());

        double scaledAttackSpeed = getScaledAttackSpeed(player);

        AttributeModifier modifier = new AttributeModifier(
                modifierUUID,
                "Hail of Blades Attack Speed",
                scaledAttackSpeed,
                AttributeModifier.Operation.ADD_SCALAR
        );

        Objects.requireNonNull(player.getAttribute(Attribute.GENERIC_ATTACK_SPEED)).addModifier(modifier);
        activeModifiers.get(player.getUniqueId()).add(modifier);
    }

    private void removeAllModifiers(Player player) {
        List<AttributeModifier> modifiers = activeModifiers.getOrDefault(player.getUniqueId(), new ArrayList<>());
        for (AttributeModifier modifier : modifiers) {
            Objects.requireNonNull(player.getAttribute(Attribute.GENERIC_ATTACK_SPEED)).removeModifier(modifier);
        }
        modifiers.clear();
    }

    @Override
    public void tick(Player player) {
        UUID playerUUID = player.getUniqueId();

        if (isOnCooldown(player)) {
            String runeDisplay = getRuneDisplay(player, RuneState.COOLDOWN, 0);
            setPlayerDisplay(player, runeDisplay);
            return;
        }

        if (windupActive.getOrDefault(playerUUID, false)) {
            int windupCount = windupTicks.getOrDefault(playerUUID, 0);
            windupCount--;
            windupTicks.put(playerUUID, windupCount);

            String runeDisplay = getRuneDisplay(player, RuneState.WINDUP, windupCount);
            setPlayerDisplay(player, runeDisplay);

            if (windupCount <= 0) {
                windupActive.put(playerUUID, false);
                activateEffect(player);
            }
            return;
        }

        if (activeState.getOrDefault(playerUUID, false)) {
            int stacks = trackActiveStacks(player);

            if (stacks <= 0) {
                deactivateEffect(player);
                return;
            }

            String runeDisplay = getRuneDisplay(player, RuneState.ACTIVE, stacks);
            setPlayerDisplay(player, runeDisplay);
            return;
        }

        String runeDisplay = getRuneDisplay(player, RuneState.IDLE, 0);
        setPlayerDisplay(player, runeDisplay);
    }

    private void activateEffect(Player player) {
        UUID playerUUID = player.getUniqueId();
        activeState.put(playerUUID, true);
        lastAttackTick.put(playerUUID, 0);
        currentStacks.put(playerUUID, INITIAL_STACKS);

        List<Integer> durations = new ArrayList<>();
        for (int i = 0; i < INITIAL_STACKS; i++) {
            durations.add(STACK_DURATION_TICKS);
        }
        stackDurationTicks.put(playerUUID, durations);

        applyAttackSpeedBonus(player);

        player.playSound(player.getLocation(), org.bukkit.Sound.ITEM_TRIDENT_THROW, 1.0f, 2.0f);
    }

    private void setPlayerDisplay(Player player, String runeDisplay) {
        PlayerStats playerStats = new PlayerStats();

        String statsDisplay = playerStats.getActionBarSections(player);

        String actionBarMessage = runeDisplay + " " + statsDisplay;
        player.sendActionBar(Component.text(actionBarMessage));
    }

    enum RuneState {
        COOLDOWN, WINDUP, ACTIVE, IDLE
    }

    private String getRuneDisplay(Player player, RuneState state, int value) {
        return switch (state) {
            case COOLDOWN -> "§7❛❟❛ " + getCooldownDisplay(player);
            case ACTIVE -> "§c❛❟❛ " + value + "/" + INITIAL_STACKS;
            case WINDUP -> getWindupDisplay(player, value);
            case IDLE -> "§4❛❟❛";
        };
    }

    private String getWindupDisplay(Player player, int remainingTicks) {
        UUID playerUUID = player.getUniqueId();

        int currentStage;
        String message;

        if (remainingTicks > (WINDUP_TICKS * 2 / 3)) {
            currentStage = 1;
            message = "§c❛§4❟❛";
        } else if (remainingTicks > (WINDUP_TICKS / 3)) {
            currentStage = 2;
            message = "§c❛❟§4❛";
        } else {
            currentStage = 3;
            message = "§c❛❟❛";
        }

        int lastStage = lastWindupStage.getOrDefault(playerUUID, 0);
        if (currentStage != lastStage) {
            player.playSound(player.getLocation(), org.bukkit.Sound.ITEM_TRIDENT_HIT, 1.0f, 2.0f);
            lastWindupStage.put(playerUUID, currentStage);
        }

        return message;
    }
}